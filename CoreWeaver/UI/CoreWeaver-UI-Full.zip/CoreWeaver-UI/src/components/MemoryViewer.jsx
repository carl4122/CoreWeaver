import React from 'react';
import { Box, Text, VStack, HStack, Badge, Button } from '@chakra-ui/react';

const dummyMemories = [
  { id: 1, type: 'Core', text: 'Makaila fell in love on June 23', impact: 5, emotion: 'Love' },
  { id: 2, type: 'Routine', text: 'Mike made her breakfast again', impact: 2, emotion: 'Joy' }
];

export default function MemoryViewer() {
  return (
    <Box>
      <Text fontSize="xl" mb={4}>Memory Viewer</Text>
      <VStack align="stretch" spacing={3}>
        {dummyMemories.map(memory => (
          <Box key={memory.id} p={4} bg="gray.700" rounded="md">
            <HStack justify="space-between">
              <Text>{memory.text}</Text>
              <Badge colorScheme="purple">{memory.type}</Badge>
            </HStack>
            <HStack mt={2}>
              <Badge colorScheme="green">Impact: {memory.impact}</Badge>
              <Badge colorScheme="pink">Emotion: {memory.emotion}</Badge>
            </HStack>
            <Button size="sm" mt={2} colorScheme="blue">Edit</Button>
          </Box>
        ))}
      </VStack>
    </Box>
  );
}