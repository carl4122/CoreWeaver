import React from 'react';
import { Box, Text, Stat, StatLabel, StatNumber, VStack } from '@chakra-ui/react';

export default function TokenStats() {
  return (
    <Box>
      <Text fontSize="xl" mb={4}>Token Usage Stats</Text>
      <VStack spacing={4}>
        <Stat>
          <StatLabel>Tokens Used</StatLabel>
          <StatNumber>23,412</StatNumber>
        </Stat>
        <Stat>
          <StatLabel>Tokens Saved</StatLabel>
          <StatNumber>6,912</StatNumber>
        </Stat>
      </VStack>
    </Box>
  );
}