import React from 'react';
import { Box, Text, Button, VStack } from '@chakra-ui/react';

export default function CharacterManager() {
  return (
    <Box>
      <Text fontSize="xl" mb={4}>Character Manager</Text>
      <VStack spacing={3} align="stretch">
        <Button colorScheme="blue">Create New Character</Button>
        <Button colorScheme="orange">Fork Timeline</Button>
        <Button colorScheme="gray">Archive Character</Button>
      </VStack>
    </Box>
  );
}