import React from 'react';
import { VStack, Button, Box } from '@chakra-ui/react';

export default function Sidebar({ onChangeView }) {
  return (
    <Box bg="gray.900" color="white" w="200px" p={4}>
      <VStack spacing={4} align="stretch">
        <Button onClick={() => onChangeView('memory')} colorScheme="teal" variant="solid">Memory Manager</Button>
        <Button onClick={() => onChangeView('character')} colorScheme="teal" variant="outline">Character Manager</Button>
        <Button onClick={() => onChangeView('tokens')} colorScheme="teal" variant="outline">Token Stats</Button>
        <Button onClick={() => onChangeView('settings')} colorScheme="teal" variant="outline">Settings</Button>
      </VStack>
    </Box>
  );
}