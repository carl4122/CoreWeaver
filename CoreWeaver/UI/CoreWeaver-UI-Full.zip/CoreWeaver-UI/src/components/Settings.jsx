import React from 'react';
import { Box, Text, Switch, FormControl, FormLabel, VStack } from '@chakra-ui/react';

export default function Settings() {
  return (
    <Box>
      <Text fontSize="xl" mb={4}>Settings</Text>
      <VStack spacing={4} align="start">
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="autosave" mb="0">Enable Auto-Save</FormLabel>
          <Switch id="autosave" />
        </FormControl>
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="darkmode" mb="0">Force Dark Mode</FormLabel>
          <Switch id="darkmode" isChecked />
        </FormControl>
      </VStack>
    </Box>
  );
}