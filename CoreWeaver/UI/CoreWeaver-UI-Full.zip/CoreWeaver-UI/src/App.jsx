import React, { useState } from 'react';
import {
  Box, Flex, Text, Select, Button, VStack, HStack
} from '@chakra-ui/react';
import Sidebar from './components/Sidebar.jsx';
import MemoryViewer from './components/MemoryViewer.jsx';
import CharacterManager from './components/CharacterManager.jsx';
import TokenStats from './components/TokenStats.jsx';
import Settings from './components/Settings.jsx';

export default function App() {
  const [view, setView] = useState('memory');
  const [model, setModel] = useState('GPT-4 Turbo');
  const [character, setCharacter] = useState('Makaila');

  return (
    <Flex height="100vh">
      <Sidebar onChangeView={setView} />
      <Box flex="1" p={4} bg="gray.800" color="white">
        <HStack spacing={4} mb={4}>
          <Select value={model} onChange={(e) => setModel(e.target.value)} w="200px">
            <option>GPT-4 Turbo</option>
            <option>GPT-3.5</option>
            <option>Claude 3</option>
            <option>Local LLM</option>
          </Select>
          <Select value={character} onChange={(e) => setCharacter(e.target.value)} w="200px">
            <option>Makaila</option>
            <option>Riven</option>
            <option>New Character +</option>
          </Select>
          <Button colorScheme="blue">Check for Updates</Button>
        </HStack>
        {
          {
            memory: <MemoryViewer />,
            character: <CharacterManager />,
            tokens: <TokenStats />,
            settings: <Settings />
          }[view]
        }
      </Box>
    </Flex>
  );
}